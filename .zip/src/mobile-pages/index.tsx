import React from "react";
import TabsView from "../mobile-component/tabs";
const MobileScreen = () => {
  return (
    <>
      <TabsView />
    </>
  );
};
export default MobileScreen;
