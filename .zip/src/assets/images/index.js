import bannerpic_0 from "./h-slide-2.jpg";
import bannerpic_1 from "./h-slide-2.jpg";
import doctorpic_0 from "./team-1.png";
import doctorpic_1 from "./team-2.png";
import doctorpic_2 from "./team-3.png";
import gallerypic_0 from "./gallery-1.png";
import gallerypic_1 from "./gallery-2.png";
import gallerypic_2 from "./gallery-3.png";
import gallerypic_3 from "./gallery-4.jpg";
import gallerypic_4 from "./gallery-5.jpg";
import gallerypic_5 from "./gallery-7.jpg";
import chosseIcon_1 from "./xci.png";
import chosseIcon_2 from "./xci-2.png";
import chosseIcon_3 from "./xci-3.png";
import chosseIcon_4 from "./xci-4.png";
const IMAGES = {
    bannerpic_0,
    bannerpic_1,
    doctorpic_0,
    doctorpic_1,
    doctorpic_2,
    gallerypic_0,
    gallerypic_1,
    gallerypic_2,
    gallerypic_3,
    gallerypic_4,
    gallerypic_5,
    chosseIcon_1,
    chosseIcon_2,
    chosseIcon_3,
    chosseIcon_4,

}

export default IMAGES

