import IMAGES from "../../../assets/images";
export const galleryImages = [
  IMAGES.gallerypic_0,
  IMAGES.gallerypic_1,
  IMAGES.gallerypic_2,
  IMAGES.gallerypic_3,
  IMAGES.gallerypic_4,
  IMAGES.gallerypic_5,
];
