import IMAGES from "../../../../assets/images";
export const doctorImages = [
    {
        imgURL: IMAGES.doctorpic_0,
        title: "Dr. Ramveer Singh Rajput",
        subtitle: "MBBS, MD - General Medicine",
    },
    {
        imgURL: IMAGES.doctorpic_1,
        title: "Dr. Khozema Saify",
        subtitle: "MBBS, MD - General Medicine",
    },
    {
        imgURL: IMAGES.doctorpic_2,
        title: "Dr.Manoj Kumar Srivastava",
        subtitle: "MBBS, MD - General Medicine",
    },
    {
        imgURL: IMAGES.doctorpic_0,
        title: "Dr. Ujjawal Sharma",
        subtitle: "MBBS, MD - General Medicine",
    },
]