import IMAGES from "../../../assets/images";

export const bannerImages = [IMAGES.bannerpic_0, IMAGES.bannerpic_1];
