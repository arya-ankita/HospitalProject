import React from "react";
import "./App.css";
import MobileRouting from "./MobileRouting";
const App = () => {
  return (
    <>
      <MobileRouting />
    </>
  );
};

export default App;
