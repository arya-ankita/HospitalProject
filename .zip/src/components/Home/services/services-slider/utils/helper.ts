export const servicescontent = [
    { icon: "flaticon-044-aesthetic", title: "Body procedures", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
    { icon: "flaticon-027-beauty", title: "Facial Procedures", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
    { icon: "flaticon-031-anatomy", title: "Breast procedures", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
    { icon: "flaticon-008-abdominoplasty", title: "Skin care &amp; Beauty", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
    { icon: "flaticon-044-aesthetic", title: "Body procedures", description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." },
]