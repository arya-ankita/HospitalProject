import IMAGES from "../../../../../assets/images"
export const doctorImages = [
    {
        imgURL: IMAGES.doctorpic_0,
        title: "Caroline Grant",
        subtitle: "Plastic surgeon",
    },
    {
        imgURL: IMAGES.doctorpic_1,
        title: "Dr. Maria Angel",
        subtitle: "Plastic surgeon",
    },
    {
        imgURL: IMAGES.doctorpic_2,
        title: "Nathan Mullins",
        subtitle: "Plastic surgeon",
    },
    {
        imgURL: IMAGES.doctorpic_0,
        title: "Caroline Grant",
        subtitle: "Plastic surgeon",
    },
]