import React from "react";
import "./smallLoader.css";
function SmallLoader() {
  return <div className="small_loader">Loading...</div>;
}

export default SmallLoader;

