const express = require('express');
const app = express();
const db = require("./models");
const dotenv = require('dotenv');
dotenv.config({ path: './config.env' });
const port = process.env.PORT || 3001;



app.get("/", (req, resp) => {
    resp.send("Home page");
})



app.listen(port, () => {
    console.log(`App is listening at port http://localhost:${port}`);
})

module.exports = app;