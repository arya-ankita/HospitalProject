const { Sequelize } = require('sequelize');
const db = require('./../models');
const User = db.users;

exports.creat= async(req,res)=>{
    try{

        
    
    
    }catch(e){}
}
