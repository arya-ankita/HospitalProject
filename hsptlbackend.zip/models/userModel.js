const DataTypes = require('sequelize');
const { sequelize } = require('..');

module.exports = sequelize => {
    const Users = {
        id: {
            type: DataTypes.INTEGER(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
            comment: null,
            field: "id"
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: null,
            field: "name"
        },
        email: {
            type: DataTypes.STRING(20000),
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: null,
            field: "email"
        },
        mobileno: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            field: "mobileno"
        },
        role: {
            type: DataTypes.STRING(100),
            enum: ['user', 'admin', 'subadmin'],
            defaultValue: 'user',
            primaryKey: false,
            autoIncrement: false,
            comment: null,
            field: "role"
        },
    };
    const options = {
        tableName: "users",
        comment: "",
        indexes: [],
        timestamps: true,
        createdAt: 'create_ts',
        updatedAt: 'update_ts',
    };
    const UserModel = sequelize.define("users", Users,);
    return UserModel;
}